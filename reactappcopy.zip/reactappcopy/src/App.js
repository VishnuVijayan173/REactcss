import React, { Component } from 'react';
import './App.css';
import Footer from './Components/Footer';
import Header from './Components/Header';
import ProductList from './Components/ProductList';
import 'bootstrap/dist/css/bootstrap.css';
import '../src/css/base.css';
import '../src/css/bootstrap-theme.min.css';
import '../src/css/bootstrap.min.css';
import '../src/css/jquery.bxslider.css';
import '../src/css/kendo.bootstrap.min.css';
import '../src/css/kendo.bootstrap.mobile.min.css';
import '../src/css/kendo.common.min.css';
import '../src/css/lib.css';
import '../src/css/pages.css';
import '../src/css/print.css';
import '../src/css/vendors.css';


class App extends Component {
  render() {
    return (
      <div>
      <Header/>
      <ProductList />
      <Footer/>
      </div>
    );
  }
}

export default App;
