import React from 'react';
import { Facebook, Pinterest, Twitter, Youtube, Linkedin } from '../Assets';
import './Footer.css';

const Footer = () => {
  return (
    <div className='footer'>
        <div className='footer-upper'>
            <div className='footer-block information'>
                <div className='title'>
                    <strong>Information</strong>
                </div>
                <ul className='list'>
                    <li><a href='/sitemap'>Sitemap</a></li>
                    <li><a href='/shipping-returns'>Shipping &amp; returns</a></li>
                    <li><a href='/privacy-notice'>Privacy notice</a></li>
                    <li><a href='/conditions-of-use'>Conditions of Use</a></li>
                    <li><a href='/about-us'>About us</a></li>
                    <li><a href='/contactus'>Contact us</a></li>
                </ul>
            </div>
            <div className='footer-block customer-service'>
                <div className='title'>
                    <strong>Customer service</strong>
                </div>
                <ul className='list'>
                    <li><a href='/search'>Search</a> </li>
                    <li><a href='/news'>News</a></li>
                    <li><a href='/blog'>Blog</a></li>
                    <li><a href='/recentlyviewedproducts'>Recently viewed products</a></li>
                    <li><a href='/compareproducts'>Compare products list</a></li>
                    <li><a href='/newproducts'>New products</a></li>
                </ul>
            </div>
            <div className='footer-block my-account'>
                <div className='title'>
                    <strong>My account</strong>
                </div>
                <ul className='list'>
                    <li><a href='/customer/info'>My account</a></li>
                    <li><a href='/order/history'>Orders</a></li>
                    <li><a href='/customer/addresses'>Addresses</a></li>
                    <li><a href='/cart'>Shopping cart</a></li>
                    <li><a href='/wishlist'>Wishlist</a></li>
                    <li><a href='/vendor/apply'>Apply for vendor account</a></li>
                </ul>
            </div>
            <div className='footer-block follow-us'>
                <div className='social'>
                    <div className='title'>
                        <strong>Follow us</strong>
                        </div>
                        <ul className='networks'>
                            <li className='facebook'><a href='http://www.facebook.com/nopCommerce' target='_blank'>
                            <img src={Facebook} alt={'Facebook'} />
                                </a></li>
                            <li className='twitter'><a href='https://twitter.com/nopCommerce' target='_blank'>
                            <img src={Twitter} alt={'Twitter'} />
                                </a></li>
                            <li className='rss'><a href='/news/rss/1'>
                            <img src={Pinterest} alt={'RSS'} />
                                </a></li>
                            <li className='youtube'><a href='http://www.youtube.com/user/nopCommerce' target='_blank'>
                            <img src={Youtube} alt={'Youtube'} />
                                </a></li>
                            <li className='google-plus'><a href='https://plus.google.com/+nopcommerce' target='_blank'>
                            <img src={Linkedin} alt={'LinkedIn'} />
                                </a></li>
                        </ul>
                    </div>
                    <div className='newsletter'>
                        <div className='title'>
                            <strong>Newsletter</strong>
                        </div>
                        <div className='newsletter-subscribe' id='newsletter-subscribe-block'>
                            <div className='newsletter-email'>
                                <input className='newsletter-subscribe-text' id='newsletter-email' name='NewsletterEmail' placeholder='Enter your email here...' type='text' value=''/>
                                <input type='button' value='Subscribe' id='newsletter-subscribe-button' className='button-1 newsletter-subscribe-button'/>
                            </div>
                        
                        <div className='newsletter-validation'>
                            {/* <span id='subscribe-loading-progress' className='please-wait'>Wait...</span> */}
                            <span className='field-validation-valid' data-valmsg-for='NewsletterEmail' data-valmsg-replace='true'></span>
                        </div>
                    </div>
                    <div className='newsletter-result' id='newsletter-result-block'></div>
                </div>
            </div>
        </div>
        <div className='footer-lower'>
            <div className='footer-info'>
                <span className='footer-disclaimer'>Copyright © 2023 Your store name. All rights reserved.</span>
            </div>
            <div className='footer-powered-by'>Powered by <a href='http://www.nopcommerce.com/'>nopCommerce</a>
            </div>
        </div>
    </div>
    );
}

export default Footer;
