import React, { Component } from 'react';
import axios from 'axios';
import '../App.css';
import './ProductList.css';
import {image1} from '../Assets';
import {image2} from '../Assets';
import {image3} from '../Assets';
import {image4} from '../Assets';
import {image5} from '../Assets';
import {image6} from '../Assets';
import {image7} from '../Assets';
import {image8} from '../Assets';
import {image9} from '../Assets';
import {image10} from '../Assets';

const url = "http://localhost:15536/sss"

class ProductList extends Component {
    constructor(props) {
        super(props);
        this.state = { data: [] };
    }

    componentDidMount() {
        axios.get(url)
            .then(response => {
                this.setState({ data: response.data });
            })
            .catch(error => {
                console.log(error);
            });

        // Polling
        // setInterval(() => {
        //     axios.get(url)
        //         .then(response => {
        //             this.setState({ data: response.data });
        //         })
        //         .catch(error => {
        //             console.log(error);
        //         });
        // }, this.props.pollInterval);
    }

    getImage = (imageUrl) => {
        if(imageUrl.includes('image1'))
            return image1;
        else if(imageUrl.includes('image2'))
            return image2;
        else if(imageUrl.includes('image3'))
            return image3;
        else if(imageUrl.includes('image4'))
            return image4;
        else if(imageUrl.includes('image5'))
            return image5;
        else if(imageUrl.includes('image6'))
            return image6;
        else if(imageUrl.includes('image7'))
            return image7;
        else if(imageUrl.includes('image8'))
            return image8;
        else if(imageUrl.includes('image9'))
            return image9;
        else if(imageUrl.includes('image10'))
            return image10;
            
            
    }

    render() {
        const commentNodes = this.state.data.map(product => (
                <div className="card">
                    <img className="card-img-top" src={this.getImage(product.imageUrl)} alt={product.name} />
                        <div className="card-body">
                        <h5 className="card-title">{product.name}</h5>
                        <p className="card-text">${product.price}</p>
                        <button className="btn btn-primary">Add to Cart</button>
                        </div>
                </div>
        ));
        
        return (
            <div className="container">
                <h2>Product List</h2>
                <div className="row">
                    {commentNodes}
                </div>
            </div>
        );
    }
}

export default ProductList;
