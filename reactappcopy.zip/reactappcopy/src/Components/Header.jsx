import React from 'react';
import '../App.css';


function Header() {
  return (
    <div class="main-header" id="wolseley-header">
    <div class="container-fluid we-theme">
        <div class="row">
            <div class="navbar navbar-default navbar-we-default" role="navigation">
                <div class="region-language-section text-right">

                    <div class="pull-right hide ">
                            <a href="#en" class="btnEnglish lang-buttons active" target="_self">English</a>
                            <span>
                                /
                            </span>
                            <a href="#fr" class="btnFrench lang-buttons" target="_self">Français</a>
                        </div>
                    </div>
                </div>
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-target=".navbar-we-default">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar x-0"></span>
                        <span class="icon-bar x-1"></span>
                        <span class="icon-bar x-2"></span>
                    </button>
                    <a class="wolseley-main-logo" href="/">Wolseley Logo</a>
                    <div class="loader-cart hide"></div>
                        <a href="/cart" class="cart cart-quantity">(13)</a>
                                            <a href="#" class="hide header-hold hard-hold hidden-xs" role="button" data-toggle="popover" data-placement="bottom" data-trigger="hover" data-content="You cannot transact at this time. Please contact our credit department to resolve this issue" title="" data-original-title="">Hard Hold</a>
                        <a href="#" class="hide header-hold hard-hold visible-xs" role="button" data-toggle="popover" data-placement="bottom" data-trigger="focus" data-content="You cannot transact at this time. Please contact our credit department to resolve this issue" title="" data-original-title="">Hard Hold</a>
                    <a href="#we-search-form" class="search-trigger-button" aria-label="Search"><span class="glyphicon glyphicon-search validate-user-region"></span></a>
                    <div class="visible-xs account-links">
                            <a href="#my-account" class="my-account-link">
                                Alen Joy
                                <span>21594 - ONTARIO CLEAN WATER</span>
                            </a>
                    </div>
                    <div id="we-search-form" class="input-group main-search">
                        

        <span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span><input type="text" class="form-control main-search-field validate-user-region ui-autocomplete-input" id="search" tabindex="1" autocomplete="off" placeholder="Browse our products" aria-label="Search Products"/>
        <span class="input-group-btn">
            <button class="btn btn-primary main-search-button" id="serch-button" type="button"><span class="glyphicon glyphicon-search validate-user-region"></span><span class="sr-only">Search Button</span></button>
        </span>
                    </div>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav" id="headerLinksTop">
                        <li>
                            <a id="shopnavlink" href="/" class="dropdown-toggle we-dropdown-toggle excludeSelectRegionshop">Shop</a>
                            
                        </li>
                        <li class="visible-xs">
                                <a href="/cart">Shopping Cart</a>
                        </li>
                       
                            
                                                                            <li class="visible-xs">
                                <a class="btnScanner GTM-btnScanner" id="btnScanner" onclick="ScannerCheck()">Barcode Scanner</a>
                            </li>
                        <li class="visible-xs"><a href="/branch-locations">Find a Branch</a></li>
                      
                        <li class="hidden-xs">
                            <a id="servicesnavlink" href="/ServicePage/GetServicePage/" class="dropdown-toggle we-dropdown-toggle">Services</a>

                        </li>
                       
                        <li class="hidden-xs">
                            <a id="supportnavlink" href="/SupportPage/GetSupportPage/" class="dropdown-toggle we-dropdown-toggle">Support</a>
                            
                        </li>
                    </ul>
                    
                    
                    <ul class="nav navbar-nav navbar-right sign-in">
                       
                            <li>
                                <a href="#" class="dropdown-toggle my-account-trigger" data-toggle="dropdown">
                                    Alen Joy
                                    <span class="hidden-xs showSwitchAccount" onclick="account.initializeGrid();" data-toggle="modal" style="cursor:pointer" data-target="#switchAccountPopup">21594 - ONTARIO CLEAN WATER</span>
                                </a>

                                <ul class="dropdown-menu my-account-dropdown">
                                    <li class="nav-list">
                                        <ul class="visible-xs">
                                            <li class="back"><a href="#">Back</a></li>

                                     
                                            <li>
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">My Branch</a>
                                                <ul class="dropdown-menu">
                                                
                                                </ul>
                                            </li>
                                    


                                            <li>
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                                    Account Information
                                                </a>
                                                <ul class="dropdown-menu nav-account-info">
                                                    
                                                </ul>
                                            </li>
                                            <li><a href="/MySettings">My Settings</a></li>
                                            <li><a href="/logout">Logout</a></li>
                                        </ul>
                                        
                                    </li>
                                </ul>
                            </li>
                                <li class="visible-xs close-menu"><a href="#" class="showSwitchAccount" data-toggle="modal" data-target="#switchAccountPopup">Switch Account</a></li>
                                <li class="visible-xs close-menu"><a href="#" onclick="profile.initializeGrid();" data-toggle="modal" data-target="#myModalBoxProfile">Switch Profile</a></li>
                                                <li class="visible-xs">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Support</a>
                            <ul class="dropdown-menu nav-support">
                                <li class="nav-list">
                                    <ul>
                                        <li class="back"><a href="#">Back</a></li>
                                        <li><a href="/branch-locations">Branch Locations</a></li>
                                        <li><a href="/help-page">Help</a></li>
                                        <li><a class="FAQView" href="/FAQ/GetFAQPage/">Frequently Asked Questions</a></li>
                                        
                                        <li><a href="/ContactUs/GetContactUsPage/">Contact Us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
  )}
  export default Header;
